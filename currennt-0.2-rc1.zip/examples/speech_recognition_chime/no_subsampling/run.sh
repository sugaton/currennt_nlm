#!/bin/sh
../../../build/currennt "$@" --options_file config.cfg 


